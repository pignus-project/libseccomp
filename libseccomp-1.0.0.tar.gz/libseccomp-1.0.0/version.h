/* automatically generated - do not edit */
#ifndef _VERSION_H
#define _VERSION_H
#define VERSION_RELEASE "1.0.0"
#endif
